const { chapinmall } = require('./empresas/chapinmall.js');
const empresas = { chapinmall }
module.exports = empresas 